from Tkinter import *
def pic():
    root1 = Tk()
    photo1 = PhotoImage(file = "hello.gif")
    gain = Label (root1, image = photo1)
    gain.pack()
    root1.mainloop()
pic()
