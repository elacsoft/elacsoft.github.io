import Tkinter as tk
from Tkinter import *
import time
import webbrowser
import LeapAppmine
import Leap, sys, thread, time
from Leap import CircleGesture, KeyTapGesture, ScreenTapGesture, SwipeGesture

hands = 0

class LeapMotionListener(Leap.Listener):
    finger_names = ['Thumb', 'Index', 'Middle', 'Ring', 'Pinky']
    bone_names = ['Metacarpal', 'Proximal','Intermediate','Distal']
    state_names = ['STATE_INVALID','STATE_START','START_UPDATE','STATE_END']

    def on_frame(self, controller):
        frame = controller.frame()
        global hands
        hands = int(len(frame.hands))
        print hands
def pic():
    root1 = Tk()
    photo1 = PhotoImage(file = "hello.gif")
    gain = Label (root1, image = photo1)
    gain.pack()
    root1.mainloop()
def website():
    new=2
    url="https://www.google.com.pk"
    webbrowser.open(url,new=new)
    '''def second():
        root = Tk()
        root.title("Leap Motion Controller")
        root.configure(background = "black")
        Label (root, text="LEAP GUI INTERFACE", bg="black", fg="white", font="none 14 bold") .grid(row=0, column=0,sticky=W)
        Label (root, text="Weather is Sunny Today", bg="black", fg="green", font=('times', 25, 'bold')) .grid(column=3, row=1, columnspan=2, sticky=W, pady=5, padx=5)
        Button(root, text="Image", width=10, height=6, command=pic) .grid(row=4, column=1, sticky=W)
        Button(root, text="Google", width=10, height=6, command=website) .grid(row=4, column=2, sticky=E)
        def tick(time1 = ''):
            time2 = time.strftime('%I:%M:%S')
            if time2 != time1:
                time1 = time2
                clock_frame.config(text=time2)
            clock_frame.after(200, tick)
        clock_frame = Label(root, font=('times', 25, 'bold'), bg='black', fg='green')
        clock_frame .grid(row=1, column=0, sticky=W)
        tick()
        root.mainloop()
        second()'''
        

'''def click():
    save = textbox.get()
    textbox.delete(0, END)
    if save == 'elacsoft':
        second()
    else:
        msg = "Wrong Password, Try Again!!"
        out.insert(END, msg)'''
    

#initialize window
'''window = Tk()
#window title
window.title("Leap Motion Controller")
#background color
window.configure(background = "black")
#logo image(only gif supported)
photo = PhotoImage(file = "logo.gif")
Label (window, image = photo, bg = "black"). grid(row=0, column = 0, sticky=E)
Label (window, text="Hello World to Leap Motion", bg="black", fg="white", font="none 14 bold") .grid(row=1, column=0,sticky=W)
Label (window, text="Enter Your Password Down", bg="black", fg="white", font="none 14 bold") .grid(row=2, column=0,sticky=W)
textbox = Entry(window, width=20, bg="white")
textbox .grid(row=4, column=0, sticky=W)
Button(window, text="SUBMIT", width=6, command=click) .grid(row=8, column=0, sticky=W)
out = Text(window, width=50, height=8, wrap=WORD, background="white")
out.grid(row=10, column=0, columnspan=2, sticky=W)'''
def main():
    while True:
        global hands
        listener = LeapMotionListener()
        controller = Leap.Controller()
        controller.add_listener(listener) 
        try:
            sys.stdin.readline()
        except KeyboardInterrupt:
            pass
        finally:
            controller.remove_listener(listener)
        if hands == 1:
            pic()
        if hands == 2:
            website()
    


if __name__ == "__main__":
    main()


















