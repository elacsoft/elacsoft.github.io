from Tkinter import *
#button click function
def click():
    save = textbox.get()
    Label (window, text="You have entered"+" "+save, bg="black", fg="white", font="none 14 bold") .grid(row=4, column=0,sticky=W)
    

#initialize window
window = Tk()
#window title
window.title("Leap Motion Controller")
#background color
window.configure(background = "black")
#logo image(only gif supported)
photo = PhotoImage(file = "logo.gif")
Label (window, image = photo, bg = "black"). grid(row=0, column = 0, sticky=E)
#text display
Label (window, text="Hello World to Leap Motion", bg="black", fg="white", font="none 14 bold") .grid(row=1, column=0,sticky=W)
#button input
Button(window, text="SUBMIT", width=6, command=click) .grid(row=3, column=0, sticky=W)

#input textbox
textbox = Entry(window, width=20, bg="white")
textbox .grid(row=2, column=0, sticky=W)

window.mainloop()
