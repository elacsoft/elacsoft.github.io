import Tkinter as tk
from Tkinter import *
import time
import webbrowser

def click():
    save = textbox.get()
    textbox.delete(0, END)
    if save == 'elacsoft':
        second()
    else:
        msg = "Wrong Password, Try Again!!"
        out.insert(END, msg)
def pic():
    root1 = tk.Toplevel()
    root1.configure(background = "black")
    #photo1 = tk.PhotoImage(file = "hello.gif")
    #gain = tk.Label (root1, image = photo1)
    #gain.pack()
    with file('data.txt') as f:
        s = f.read()
        textbox1 = Entry(window, width=20, bg="white")
        textbox1 .grid(row=4, column=0, sticky=W)
        out1 = Text(root1, width=50, height=8, wrap=WORD, background="blue")
        out1.grid(row=10, column=0, columnspan=2, sticky=W)
        textbox1.delete(0, END)
        out1.insert(END, s)
    root1.mainloop()
def website():
    new=2
    url="https://192.168.4.1:8080"
    webbrowser.open(url,new=new)

#initialize window
window = Tk()
#window title
window.title("Attendance system")
#background color
window.configure(background = "black")
#logo image(only gif supported)
photo = PhotoImage(file = "att.gif")
Label (window, image = photo, bg = "black"). grid(row=0, column = 0, sticky=E)
Label (window, text="Hello Sir", bg="black", fg="white", font="none 14 bold") .grid(row=1, column=0,sticky=W)
Label (window, text="Enter Your Password Down", bg="black", fg="white", font="none 14 bold") .grid(row=2, column=0,sticky=W)
textbox = Entry(window, width=20, bg="white")
textbox .grid(row=4, column=0, sticky=W)
Button(window, text="SUBMIT", width=6, command=click) .grid(row=8, column=0, sticky=W)
out = Text(window, width=50, height=8, wrap=WORD, background="white")
out.grid(row=10, column=0, columnspan=2, sticky=W)

def second():
    root = Tk()
    #window title
    root.title("Attendance system")
    #background color
    root.configure(background = "black")
    Label (root, text="Attendance Database", bg="black", fg="white", font="none 14 bold") .grid(row=0, column=0,sticky=W)
    Label (root, text="Weather Update", bg="black", fg="green", font=('times', 25, 'bold')) .grid(column=3, row=1, columnspan=2, sticky=W, pady=5, padx=5)
    Button(root, text="Data Base", width=10, height=6, command=pic) .grid(row=4, column=1, sticky=W)
    Button(root, text="Google", width=10, height=6, command=website) .grid(row=4, column=2, sticky=E)
    def tick(time1 = ''):
        time2 = time.strftime('%I:%M:%S')
        if time2 != time1:
            time1 = time2
            clock_frame.config(text=time2)
        clock_frame.after(200, tick)
    clock_frame = Label(root, font=('times', 25, 'bold'), bg='black', fg='green')
    clock_frame .grid(row=1, column=0, sticky=W)
    tick()
    root.mainloop()
window.mainloop()
